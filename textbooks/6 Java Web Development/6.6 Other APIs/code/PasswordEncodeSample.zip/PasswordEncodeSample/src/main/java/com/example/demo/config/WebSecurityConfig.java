package com.example.demo.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

import com.example.demo.dao.UserDao;
import com.example.demo.models.UserEntity;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig {
	@Bean
	/*formLogin()メソッドを使用して、フォームベースのログインを構成しています。
	 * ログインページのURL、成功時のリダイレクト先、リクエストパラメータの名前、失
	 * 敗時のリダイレクト先などを指定しています。また、logout()メソッドを使用してログアウト機能を構成しており、
	 * ログアウト成功時のリダイレクト先を指定しています。*/
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.formLogin(login -> login// フォーム認証の設定記述開始
				.loginPage("/login")// ログイン画面のURL
				.defaultSuccessUrl("/hello", true) // ログインが成功したときの遷移先
				.usernameParameter("username") // リクエストパラメータのusername属性を明示
				.passwordParameter("password")// リクエストパラメータのpassword属性を明示
				.failureUrl("/login?error")// ログインに失敗したときの遷移先
				.permitAll()// ログイン画面は未ログインでもアクセス可能
		).logout(logout -> logout// ログアウトの設定の記載を開始していきます。
				.logoutSuccessUrl("/login")// ログアウト成功後の遷移先URL
		).authorizeHttpRequests(authz -> authz// URLごとの許可の設定の記述を開始します
				.requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
				.requestMatchers("/register", "/css/**").permitAll()// ログイン無しでもアクセス可能
				.anyRequest().authenticated()// 他のURLはログイン後のみアクセス可能
		);
		return http.build();
	}
	

	@Autowired
	private UserDao userDao;
	
	// InMemoryUserDetailsManager では、ユーザー検証のために必要なユーザー情報をメモリに記憶します
	public static InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
	
	/*
	 * 新しいユーザー情報を manager に追加します。
	 * データベースに情報を追加するためには、別途コードが必要です。
	 */
	public static void addUser(String username, String password) {
		manager.createUser(User.builder()
				.username(username)
				.password("{bcrypt}" + password) // パスワードが BCyprt アルゴリズムで暗号化したことを説明
				.roles("USER")
				.build());
	}

	@Bean
	/*
	 * userDetailsService()メソッドを定義しています。
	 * このメソッドは、Spring Securityによって提供されるUserDetailsServiceインターフェースを実装しています。
	 * このメソッドはサーバーが起動するとき実行され、データベースにあるユーザー情報をメモリに記憶することによってユーザー検証をできるようにします。
	 */
	public UserDetailsService userDetailsService() {
		
		List<UserEntity> accountList = userDao.findAll(); // すべてのユーザー情報を獲得
		
		// ユーザー情報ごと manager に保存
		accountList.stream().forEach(user -> addUser(user.getUsername(), user.getPassword()));

		return manager;
	}

}