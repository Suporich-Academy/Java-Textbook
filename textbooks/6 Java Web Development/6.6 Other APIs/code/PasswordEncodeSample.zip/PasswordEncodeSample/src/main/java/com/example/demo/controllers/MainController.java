package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.config.WebSecurityConfig;
import com.example.demo.dao.UserDao;
import com.example.demo.models.UserEntity;

@Controller
public class MainController {
	@Autowired
	private UserDao userDao;
	
	@GetMapping("/login") 
	public String getLoginPage() {
		return "login";
	}

	@GetMapping("/register") 
	public String getRegisterPage() {
		return "register";
	}
	
	@PostMapping("/register")
	public String register(@RequestParam String username, @RequestParam String password) {
		if (userDao.findByUsername(username) != null) {
			return "redirect:/register?error"; // ユーザー名はすでに登録された場合は、エラーメッセージを出す
		} else {
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			String encodedPassword = passwordEncoder.encode(password); // BCrypt アルゴリズムでパスワードを暗号化
			userDao.save(new UserEntity(username, encodedPassword)); // 暗号化したパスワードをデータベースに保存
			WebSecurityConfig.addUser(username, encodedPassword); // 暗号化したパスワードをメモリに記憶
		}

		return "redirect:/login";
	}
	
	@GetMapping("/")
	public String index() {
		return "redirect:/hello";
	}
	
	@GetMapping("/hello")
	public ModelAndView getHelloPage(ModelAndView mav) {
		UserDetails user = (UserDetails) SecurityContextHolder
				.getContext().getAuthentication().getPrincipal();

		mav.addObject("name", user.getUsername());
		mav.setViewName("hello");
		return mav;
	}
}
