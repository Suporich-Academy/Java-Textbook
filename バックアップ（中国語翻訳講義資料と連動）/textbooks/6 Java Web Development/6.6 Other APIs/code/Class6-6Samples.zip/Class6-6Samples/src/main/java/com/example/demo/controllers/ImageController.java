package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.dao.ImageDao;
import com.example.demo.models.ImageEntity;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
public class ImageController {
	@Autowired
	private ImageDao imageDao;
	
	/**
	 * 保存されたすべての画像のパスを取得し、画面に表示する
	 */
	@GetMapping("/image/list")
	public ModelAndView showImageList(ModelAndView mav) {
		mav.addObject("images", imageDao.findAll());
		mav.setViewName("image-list");
		return mav;
	}
	
	/**
	 * 画像追加ページを取得
	 */
	@GetMapping("/image/add")
	public String getImageAddingPage() {
		return "image-add";
	}

	/**
	 * ユーザーがアップロードした画像を保存する
	 */
	@PostMapping("/image/add")
	public String addImage(@RequestParam MultipartFile image) throws IOException {
		// 画像がサーバー上のファイル名を生成する。ルール：今の時間 + 元のファイル名
		String fileName = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss-").format(new Date()) + image.getOriginalFilename();
		
		// ファイルをサーバーに保存する
		Files.copy(image.getInputStream(), Path.of("src/main/resources/static/images/" + fileName));
		
		// ファイル名をデータベースに保存する
		imageDao.save(new ImageEntity(fileName));
		
		// 画像一覧に戻る
		return "redirect:/image/list";
	}
}
