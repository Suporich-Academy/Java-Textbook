package com.example.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RedirectController {
	@GetMapping("/rdr/main") 
	public String getMainPage() {
		return "redirect-main";
	}
	
	/**
	 * この URL をアクセスすれば、「/rdr/target」にリダイレクトする
	 */
	@GetMapping("/rdr/to/target") 
	public String redirectToTarget() {
		String param1 = "apple";
		String param2 = "banana";
		// この２つの変数は、直接にパスに書き込むことによってリダイレクト先のコントローラーに伝える
		// この書き方では、フォームに「param1」と「param2」の２つの <input> を作ってデータを送ることと同等である		
		return "redirect:/rdr/target" + "?param1=" + param1 + "&param2=" + param2;
	}

	@GetMapping("/rdr/target") 
	public ModelAndView redirectTarget(ModelAndView mav, @RequestParam String param1, @RequestParam String param2) {
		mav.addObject("param1", param1);
		mav.addObject("param2", param2);
		mav.setViewName("redirect-result");
		return mav;
	}

	/**
	 * 外部の URL にも遷移できる
	 */
	@GetMapping("/rdr/to/other") 
	public String redirectToOtherServer() {
		return "redirect:https://www.google.com";
	}

	/**
	 * この URL をアクセスすれば、「/fwd/target」にフォーワードする
	 */
	@GetMapping("/fwd/to/target") 
	public ModelAndView forwardToTarget(ModelAndView mav) {
		mav.addObject("param1", "Alice");
		mav.addObject("param2", "Bob");		
		// mav に入れた変数は、遷移先のコントローラーでそのまま保持する
		mav.setViewName("forward:/fwd/target");
		return mav;
	}

	@GetMapping("/fwd/target") 
	public ModelAndView forwardTarget(ModelAndView mav) {
		mav.setViewName("forward-result");
		return mav;
	}
}
