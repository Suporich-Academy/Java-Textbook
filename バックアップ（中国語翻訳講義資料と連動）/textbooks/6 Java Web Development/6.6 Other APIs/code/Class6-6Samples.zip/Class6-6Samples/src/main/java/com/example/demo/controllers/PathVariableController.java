package com.example.demo.controllers;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PathVariableController {
	@GetMapping("/path/view")
	public String getPathViewPage() {
		return "path-view";
	}
	
	@GetMapping("/path/content/{num}")
	public ModelAndView showContent(@PathVariable int num, ModelAndView mav) {
		mav.addObject("num", num); // パスパラメータで得られた変数「num」を、Thymeleaf に伝える
		mav.setViewName("path-content");
		return mav;
	}
	
	@GetMapping("/path/content/{num1}/{num2}")
	public ModelAndView showContentMult(@PathVariable int num1, @PathVariable int num2, ModelAndView mav) {
		mav.addObject("num1", num1); // パスパラメータで得られた変数「num1」を、Thymeleaf に伝える
		mav.addObject("num2", num2); // パスパラメータで得られた変数「num2」を、Thymeleaf に伝える
		mav.setViewName("path-content-mult");
		return mav;
	}
}
