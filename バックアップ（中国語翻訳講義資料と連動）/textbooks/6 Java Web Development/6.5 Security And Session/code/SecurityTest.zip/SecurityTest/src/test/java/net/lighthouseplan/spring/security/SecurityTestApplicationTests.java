package net.lighthouseplan.spring.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
